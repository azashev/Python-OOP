from elf import Elf


class MuseElf(Elf):
    pass
