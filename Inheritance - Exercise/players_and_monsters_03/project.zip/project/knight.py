from hero import Hero


class Knight(Hero):
    pass
