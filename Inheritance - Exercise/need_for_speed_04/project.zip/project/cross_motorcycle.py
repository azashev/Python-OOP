from motorcycle import Motorcycle


class CrossMotorcycle(Motorcycle):
    pass
