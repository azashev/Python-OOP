from dog_hinh import Dog
from cat_hinh import Cat


# In a folder called project create three files: animal_hinh.py, dog_hinh.py, and cat_hinh.py.
# In each file, create its corresponding class - Animal, Dog, and Cat:
# • Animal with a single method eat() that returns: "eating..."
# • Dog with a single method bark() that returns: "barking..."
# • Cat with a single method meow() that returns: "meowing..."
# Both Dog and Cat should inherit from Animal.
